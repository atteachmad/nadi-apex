const VERSION = '1.1.0';
const PAGE_ORIGIN = 'https://atteachmad.github.io/';
const APEX_RE = /^https:\/\/dash-ccc0[123]\.jne\.co\.id\//;
const NAME_RE = /^AWB_[A-Za-z0-9_]+_Part\d+\.csv$/;
const DASH = {
  ccc1: 'https://dash-ccc01.jne.co.id/apex/f?p=105:LOGIN::::::',
  ccc2: 'https://dash-ccc02.jne.co.id/apex/f?p=105:LOGIN::::::',
  ccc3: 'https://dash-ccc03.jne.co.id/apex/f?p=105:LOGIN::::::'
};

let chain = Promise.resolve();
function mutate(fn) {
  const p = chain.then(async () => {
    const { job } = await chrome.storage.local.get('job');
    const j = job || { state: 'idle', files: [], logs: [], seq: 0 };
    const out = await fn(j);
    await chrome.storage.local.set({ job: j });
    return out;
  });
  chain = p.catch(() => {});
  return p;
}
async function getJob() {
  const { job } = await chrome.storage.local.get('job');
  return job || { state: 'idle', files: [], logs: [], seq: 0 };
}
function addLog(j, msg, level) {
  j.seq = (j.seq || 0) + 1;
  j.logs = j.logs || [];
  j.logs.push({ seq: j.seq, t: Date.now(), msg: String(msg), level: level || 'INFO' });
  if (j.logs.length > 600) j.logs.splice(0, j.logs.length - 600);
}
async function focusTab(id) {
  try {
    const t = await chrome.tabs.update(id, { active: true });
    await chrome.windows.update(t.windowId, { focused: true });
  } catch (e) {}
}

// Hasil unduhan dari APEX masuk ke Downloads\NadiX-APEX (hanya saat job berjalan)
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const url = item.finalUrl || item.url || '';
  if (!APEX_RE.test(url)) return;
  getJob().then((j) => {
    if (j.state === 'running') {
      suggest({ filename: 'NadiX-APEX/' + item.filename.split(/[\\/]/).pop(), conflictAction: 'uniquify' });
    } else suggest();
  });
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  mutate((j) => {
    if (j.state === 'running' && j.tabId === tabId) {
      j.state = 'cancelled';
      addLog(j, 'Tab APEX ditutup, proses dihentikan.', 'WARN');
    }
  });
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  handle(msg, sender)
    .then(reply)
    .catch((e) => reply({ ok: false, error: String((e && e.message) || e) }));
  return true;
});

async function handle(msg, sender) {
  const url = sender.url || '';
  const c = msg.cmd;
  const p = msg.payload || {};

  // ---------- perintah dari halaman NadiX-Bot ----------
  if (url.startsWith(PAGE_ORIGIN)) {
    if (c === 'ping') return { ok: true, version: VERSION };

    if (c === 'reset') {
      const cur = await getJob();
      if (cur.state === 'running') return { ok: false, error: 'busy' };
      const all = await chrome.storage.local.get(null);
      const keys = Object.keys(all).filter((k) => k.startsWith('f:'));
      if (keys.length) await chrome.storage.local.remove(keys);
      await mutate((j) => {
        Object.keys(j).forEach((k) => delete j[k]);
        Object.assign(j, { state: 'collecting', files: [], logs: [], seq: 0, id: Date.now() });
      });
      return { ok: true };
    }

    if (c === 'addFile') {
      if (!NAME_RE.test(p.name || '') || typeof p.text !== 'string') return { ok: false, error: 'file' };
      const cur = await getJob();
      if (cur.state !== 'collecting') return { ok: false, error: 'state' };
      await chrome.storage.local.set({ ['f:' + p.name]: p.text });
      await mutate((j) => { j.files.push({ name: p.name, st: 'pending' }); });
      return { ok: true };
    }

    if (c === 'start') {
      if (!DASH[p.dash]) return { ok: false, error: 'dash' };
      const cur = await getJob();
      if (cur.state !== 'collecting' || cur.files.length === 0) return { ok: false, error: 'state' };
      // tab dibuka di latar belakang (tidak merebut fokus dari NadiX-Bot)
      const tab = await chrome.tabs.create({ url: DASH[p.dash], active: false });
      // kredensial hanya disimpan di memori sesi browser (hilang saat Chrome ditutup)
      if (p.user && p.pass) await chrome.storage.session.set({ cred: { user: String(p.user), pass: String(p.pass) } });
      else await chrome.storage.session.remove('cred');
      await mutate((j) => {
        j.state = 'running';
        j.phase = 'login';
        j.dash = p.dash;
        j.monitor = !!p.monitor;
        j.tabId = tab.id;
        j.nadixTabId = sender.tab && sender.tab.id;
        j.startedAt = Date.now();
        j.auto = !!(p.user && p.pass);
        addLog(j, `Membuka dashboard ${p.dash.toUpperCase()} di latar belakang...`, 'SYSTEM');
      });
      return { ok: true };
    }

    if (c === 'status') {
      const j = await getJob();
      const since = Number(p.since) || 0;
      return {
        ok: true, state: j.state, phase: j.phase, monitor: !!j.monitor,
        files: (j.files || []).map((f) => ({ name: f.name, st: f.st })),
        logs: (j.logs || []).filter((l) => l.seq > since), seq: j.seq || 0
      };
    }

    if (c === 'cancel') {
      const j = await getJob();
      await mutate((x) => { if (x.state === 'running') { x.state = 'cancelled'; addLog(x, 'Dibatalkan pengguna.', 'WARN'); } });
      await chrome.storage.session.remove('cred');
      if (j.tabId) try { await chrome.tabs.remove(j.tabId); } catch (e) {}
      return { ok: true };
    }
    return { ok: false, error: 'cmd' };
  }

  // ---------- perintah dari halaman APEX (tab milik job) ----------
  if (APEX_RE.test(url) && sender.tab) {
    const j = await getJob();
    const mine = sender.tab.id === j.tabId;

    if (c === 'cs_get') {
      return { ok: true, mine, job: { auto: j.auto, state: j.state, phase: j.phase, monitor: j.monitor, startedAt: j.startedAt, files: j.files } };
    }
    if (!mine || j.state !== 'running') return { ok: false, error: 'not_mine' };

    if (c === 'cs_cred') {
      const r = await chrome.storage.session.get('cred');
      return r.cred ? { ok: true, cred: r.cred } : { ok: false };
    }
    if (c === 'cs_getfile') {
      const key = 'f:' + p.name;
      const r = await chrome.storage.local.get(key);
      return typeof r[key] === 'string' ? { ok: true, text: r[key] } : { ok: false };
    }
    if (c === 'cs_download') {
      if (!APEX_RE.test(p.url || '')) return { ok: false, error: 'url' };
      await chrome.downloads.download({ url: p.url, conflictAction: 'uniquify' });
      return { ok: true };
    }
    if (c === 'cs_op') {
      let after = null;
      const toRemove = [];
      await mutate((x) => {
        for (const o of p.ops || []) {
          if (o.op === 'log') addLog(x, o.msg, o.level);
          else if (o.op === 'phase') x.phase = o.phase;
          else if (o.op === 'file') {
            const f = x.files.find((q) => q.name === o.name);
            if (f) { f.st = o.st; if (o.t) f.t = o.t; }
            if (['uploaded', 'downloaded', 'error'].includes(o.st)) toRemove.push('f:' + o.name);
          } else if (o.op === 'done') {
            x.state = 'done'; addLog(x, 'Semua proses selesai.', 'SUCCESS'); after = 'done';
          } else if (o.op === 'error') {
            x.state = 'error'; addLog(x, o.msg, 'ERROR'); after = 'error';
          } else if (o.op === 'focusNadix') after = after || 'focusNadix';
          else if (o.op === 'focusApex') after = after || 'focusApex';
        }
      });
      if (toRemove.length) await chrome.storage.local.remove(toRemove);
      if (after === 'done' || after === 'error') await chrome.storage.session.remove('cred');
      if (after === 'focusNadix' || after === 'error') await focusTab(j.nadixTabId);
      else if (after === 'focusApex') await focusTab(j.tabId);
      else if (after === 'done') {
        setTimeout(async () => {
          try { await chrome.tabs.remove(j.tabId); } catch (e) {}
        }, 1500);
      }
      return { ok: true };
    }
  }
  return { ok: false, error: 'forbidden' };
}
