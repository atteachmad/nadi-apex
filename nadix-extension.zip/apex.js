// Berjalan di halaman dash-ccc01/02/03. Hanya aktif jika tab ini milik job NadiX-Bot yang sedang berjalan.
(async () => {
  const send = (m) => new Promise((res) => {
    try { chrome.runtime.sendMessage(m, (r) => res(chrome.runtime.lastError ? null : r)); } catch (e) { res(null); }
  });
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const op = (...ops) => send({ cmd: 'cs_op', payload: { ops } });
  const L = (msg, level) => ({ op: 'log', msg, level: level || 'INFO' });
  const reportUrl = () => location.href.replace(/(f\?p=\d+:)\d+(:\d+).*/, (m, a, b) => a + '45' + b + ':::::');
  const getJob = async () => { const r = await send({ cmd: 'cs_get' }); return r && r.ok && r.mine ? r.job : null; };
  const WORDS = ['done', 'on process', 'process', 'error', 'failed', 'queue', 'waiting', 'running'];
  const MAX_WAIT_MS = 6 * 3600 * 1000;

  const rowByName = (name) => [...document.querySelectorAll('tr')].find((tr) =>
    [...tr.children].some((td) => td.tagName === 'TD' && td.textContent.includes(name)));

  function rowInfo(tr) {
    const cells = [...tr.children].map((c) => c.textContent.trim());
    let status = cells.find((c) => WORDS.includes(c.toLowerCase())) || '';
    const link = [...tr.querySelectorAll('a')].find((a) => /download/i.test(a.textContent));
    if (link && !status) status = 'Done';
    return { status, link, text: cells.join(' | ') };
  }

  async function upload(f) {
    const r = await send({ cmd: 'cs_getfile', payload: { name: f.name } });
    if (!r || !r.ok) throw new Error('Isi file ' + f.name + ' tidak ditemukan di ekstensi.');
    const sel = [...document.querySelectorAll('select')].find((s) => [...s.options].some((o) => /upload connote/i.test(o.text)));
    if (sel) {
      const opt = [...sel.options].find((o) => /upload connote/i.test(o.text));
      if (sel.value !== opt.value) {
        sel.value = opt.value;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(600);
      }
    }
    const input = document.querySelector('input[type="file"]');
    const dt = new DataTransfer();
    dt.items.add(new File([r.text], f.name, { type: 'text/csv' }));
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(300);
    const btn = [...document.querySelectorAll('button, input[type="button"], input[type="submit"], a')]
      .find((e) => /^process$/i.test((e.innerText || e.value || '').trim()));
    if (!btn) throw new Error('Tombol Process tidak ditemukan di halaman APEX.');
    await op({ op: 'file', name: f.name, st: 'submitting', t: Date.now() }, L('Upload ' + f.name + ' ...'));
    btn.click();
    // jika halaman berpindah, skrip ini ikut hilang; kalau masih hidup setelah 3 menit berarti form tidak terkirim
    setTimeout(() => op({ op: 'error', msg: 'Tombol Process sudah diklik tetapi halaman tidak berpindah (3 menit).' }), 180000);
  }

  async function main(job) {
    // 1. Halaman login: isi otomatis dari kredensial NadiX-Bot; jika tidak ada/gagal, minta pengguna klik Login
    const pw = document.querySelector('input[type="password"]');
    if (pw) {
      const tries = Number(sessionStorage.getItem('nadix_login') || 0) + 1;
      sessionStorage.setItem('nadix_login', String(tries));
      const cr = job.auto && tries <= 2 ? await send({ cmd: 'cs_cred' }) : null;
      if (cr && cr.ok) {
        const un = [...document.querySelectorAll('input')].find((i) => ['text', 'email', ''].includes(i.type) && i.offsetParent !== null);
        const setV = (el, v) => {
          const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
          d.set.call(el, v);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        };
        setV(un, cr.cred.user); setV(pw, cr.cred.pass);
        const lb = [...document.querySelectorAll('button, input[type="submit"], input[type="button"]')]
          .find((e) => /^login$/i.test((e.innerText || e.value || '').trim()));
        await op(L('Mengisi user & password, login otomatis...'));
        await sleep(400);
        if (lb) lb.click(); else pw.form && pw.form.submit();
        return;
      }
      await op({ op: 'phase', phase: 'login' },
        L(job.auto ? 'Login otomatis gagal (user/password salah?). Klik Login manual di tab APEX.' : 'Halaman login APEX terbuka. Klik tombol Login di tab APEX.', 'WARN'),
        { op: 'focusApex' });
      return;
    }
    sessionStorage.removeItem('nadix_login');
    if (job.phase === 'login') {
      await op({ op: 'phase', phase: 'upload' }, L('Login berhasil.', 'SUCCESS'));
      job.phase = 'upload';
    }

    // 2. Menuju halaman Report Status AWB (halaman 45)
    if (!document.querySelector('input[type="file"]')) {
      const n = Number(sessionStorage.getItem('nadix_nav') || 0) + 1;
      sessionStorage.setItem('nadix_nav', String(n));
      if (n > 4) { await op({ op: 'error', msg: 'Gagal menemukan halaman Report Status AWB (form upload tidak muncul).' }); return; }
      if (/f\?p=\d+:\d+:\d+/.test(location.href)) { location.href = reportUrl(); return; }
      const el = [...document.querySelectorAll('a')].find((a) => /report status awb/i.test((a.textContent || '').replace(/\u00a0/g, ' ')));
      if (el) { el.click(); return; }
      await op({ op: 'error', msg: 'Menu Report Status AWB tidak ditemukan.' });
      return;
    }
    sessionStorage.removeItem('nadix_nav');

    // 3. Konfirmasi file yang barusan dikirim: nama harus muncul di tabel Status
    const sub = job.files.find((f) => f.st === 'submitting');
    if (sub) {
      if (rowByName(sub.name)) {
        await op({ op: 'file', name: sub.name, st: 'uploaded' }, L(sub.name + ' terupload.', 'SUCCESS'));
        job = await getJob();
        if (!job) return;
      } else {
        if (Date.now() - (sub.t || 0) > 300000) {
          await op({ op: 'error', msg: sub.name + ' tidak muncul di tabel Status dalam 5 menit.' });
          return;
        }
        setTimeout(() => { location.href = reportUrl(); }, 1500);
        return;
      }
    }

    // 4. Upload file berikutnya (satu per satu)
    const next = job.files.find((f) => f.st === 'pending');
    if (next) { await upload(next); return; }

    // 5. Semua terkirim
    if (!job.monitor) { await op({ op: 'done' }); return; }

    // 6. Pantau status, unduh yang Done
    if (job.phase !== 'monitor') await op({ op: 'phase', phase: 'monitor' }, L('Semua file terupload. Memantau hasil di APEX...'));
    if (Date.now() - (job.startedAt || Date.now()) > MAX_WAIT_MS) {
      await op({ op: 'error', msg: 'Batas tunggu 6 jam terlampaui.' });
      return;
    }
    let waiting = 0;
    for (const f of job.files.filter((x) => x.st === 'uploaded')) {
      const tr = rowByName(f.name);
      if (!tr) { waiting++; continue; }
      const info = rowInfo(tr);
      const s = info.status.toLowerCase();
      if (s.includes('done')) {
        if (!info.link) { await op(L(f.name + ': Done tetapi link Download belum ada. Isi baris: ' + info.text, 'WARN')); waiting++; continue; }
        const href = info.link.href || '';
        if (/^https?:/i.test(href)) {
          const r = await send({ cmd: 'cs_download', payload: { url: href } });
          if (!r || !r.ok) { await op(L('Download ' + f.name + ' gagal, dicoba lagi nanti.', 'WARN')); waiting++; continue; }
          await op({ op: 'file', name: f.name, st: 'downloaded' }, L('Hasil ' + f.name + ' diunduh (Downloads\\NadiX-APEX).', 'SUCCESS'));
        } else {
          await op({ op: 'file', name: f.name, st: 'downloaded' }, L('Hasil ' + f.name + ' diunduh (Downloads).', 'SUCCESS'));
          info.link.click();
        }
      } else if (s.includes('error') || s.includes('fail')) {
        await op({ op: 'file', name: f.name, st: 'error' }, L('ERROR di APEX untuk ' + f.name + ': ' + info.text, 'ERROR'));
      } else {
        waiting++;
      }
    }
    if (waiting === 0) { await op({ op: 'done' }); return; }
    await op(L('Menunggu ' + waiting + ' file diproses APEX. Cek ulang 60 detik lagi...'));
    setTimeout(() => { location.href = reportUrl(); }, 60000);
  }

  const job = await getJob();
  if (!job || job.state !== 'running') return;
  try { await main(job); }
  catch (e) { await op({ op: 'error', msg: 'Kesalahan di halaman APEX: ' + (e && e.message || e) }); }
})();
