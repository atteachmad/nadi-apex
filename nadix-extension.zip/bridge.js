// Jembatan: halaman NadiX-Bot <-> background ekstensi
window.addEventListener('message', (e) => {
  if (e.source !== window || !e.data || e.data.source !== 'nadix-page') return;
  const { id, cmd, payload } = e.data;
  const reply = (result) => window.postMessage({ source: 'nadix-ext', id, result }, '*');
  try {
    chrome.runtime.sendMessage({ cmd, payload }, (res) => {
      const err = chrome.runtime.lastError;
      reply(err ? { ok: false, error: err.message } : res);
    });
  } catch (err) {
    reply({ ok: false, error: String(err && err.message || err) });
  }
});
